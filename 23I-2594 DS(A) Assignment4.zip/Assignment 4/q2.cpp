
 ///NAME= SANA ULLAH FAROOQI
 //CLASS =BSDS(A)
 //ROLL NO = 23I-2594



#include<iostream>
#include<random>
using namespace std;
int main(){
    int k;
    cout<<"Input the size of the matrix :";
    cin>> k;
    int matrix[50][50];
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist(-50,50);
    cout<<"\nRandomly generated matrix:"<<endl;
    for (int i=0; i<k; ++i)
    {
        for (int j = 0; j < k; ++j)
        
        {
            matrix[i][j]=dist(gen);
            cout<< matrix[i][j]<<"\t";

        }
        cout<<endl;
        }
        cout<<"FINAL MATYRIX:"<<endl;
        int t=0;
       int b= k-1;
       int l= 0;
        int r=k-1;
        while(t<=b && l<=r){
        for(int i=l; i<=r; ++i)
        {
            cout<< matrix[t][i]<< " > ";

        }
        t++;
        for(int i=t; i<=b; ++i)
        {
            cout<<matrix[i][r]<<" > ";
        }
        r--;
        if (t<=b)
        {
            for (int i = r; i >=l; --i)
            {
                cout<< matrix[b][i]<< " > ";
            }
            b--;
            
        }
        if (l<=r)
        {
            for (int i = b; i >= t; --i)
            {
                cout<< matrix[i][l]<<" > ";
            }
            l++;
            
        }
        
        
        }
        cout<<"\b \b";
        return 0;
}
   