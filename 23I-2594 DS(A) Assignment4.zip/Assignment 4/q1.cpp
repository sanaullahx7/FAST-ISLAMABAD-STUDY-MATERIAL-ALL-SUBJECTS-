 ///NAME= SANA ULLAH FAROOQI
 //CLASS =BSDS(A)
 //ROLL NO = 23I-2594




#include <iostream>
#include <cstdlib>
#include <ctime>
#include<stdio.h>
#include<conio.h>

using namespace std;

int main() {
    
    bool decide = false;
    char maze[50][50] = {
        "# # # # # # # # # # # # # # # # # # # # # # # # #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . # # # # # # . . . . . . . # # # # # # . . #",
        "# . . # # # # # # . . . . . . . # # # # # # . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . . # . . . # # # # # # # # # . . . # . . . #",
        "# . . . # . . . . . . . # . . . . 8 . . # . . . #",
        "# . . . # . . . . . . . # . . . . . . . # . . . #",
        "# . . . # . . . . . . . # . . . . . . . # . . . #",
        "# . . . # # # # # # . . # . . # # # # # # . . . #",
        "# . . . # . . . . . . . # . . . . . . . # . . . #",
        "# . . . # . . . . . . . . . . . . . . . # . . . #",
        "# . . . # . . . . . . . . . . . . . . . # . . . #",
        "# . . . # . . . # # # . . . # # # . . . # . . . #",
        "# . . . . . . . # . . . . . . . # . . . . . . . #",
        "# . . . . . . . # . . . . . . . # . . . . . . . #",
        "# . . . . . . . # . . . > . . . # . . . . . . . #",
        "# . . # # # # . # . . . . . . . # . # # # # . . #",
        "# . . # # # # . # # # # # # # # # . # # # # . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# . . . . . . . . . . . . . . . . . . . . . . . #",
        "# # # # # # # # # # # # # # # # # # # # # # # # #"
    };

    int Rows = 19;
    int columns = 24;
    maze[Rows][columns] = '>';
    int row = 1;
    int c = 1;
    int count = 25;
    bool win = false;

    while (true) {
        maze[row][c] = '.';
        while (true) {
            srand(time(0));
            row = rand() % 24 + 1;
            c = rand() % 24 + 1;

            if (maze[row][c] != '#') {
                maze[row][c] = '8';
                maze[row][c] = '8';
                break;
            } else continue;
        }

        
        for (int i = 0; i < 50; i++) {
            for (int j = 0; j < 50; j++) {
                cout << maze[i][j];
            }
            cout << endl;
        }

        
		cout << "Enter the specific key to move your so called PAC MAN .-." << endl;
		cout << "1) UP" << endl;
		cout << "2) Down" << endl;
		cout << "3) Left" << endl;
		cout << "4) Right" << endl;
        int choice;
		cin >> choice;
		switch (choice)
		{
		case 1:
			if ((maze[Rows-1][columns] != '#') && (maze[Rows-2][columns] != '8'))
			{
				maze[Rows][columns] = ' ';
				Rows -= 2;
				maze[Rows][columns] = 'V';

			}
			else
			{
				
				decide = true;
			}
			break;
		case 2:
			if ((maze[Rows+1][columns] != '#') && (maze[Rows+2][columns] != '8'))
			{
				maze[Rows][columns] = ' ';
				Rows += 2;
				maze[Rows][columns] = '^';

			}
			else
			{
				
				decide = true;
			}
			break;
		case 3:
			
			if ((maze[Rows][columns-2] != '#') && (maze[Rows][columns-2] != '8'))
			{
				maze[Rows][columns] = ' ';
				columns -= 2;
				maze[Rows][columns] = '>';

			}
			else
			{
				
				decide = true;
			}
			break;
		case 4:
			if ((maze[Rows][columns+2] != '#') && (maze[Rows][columns+2] != '8'))
			{
				maze[Rows][columns] = ' ';
				columns += 2;
				maze[Rows][columns] = '<';

			}
			else
			{
				
				decide = true;
			}
			if ((maze[Rows][columns+2] == '#') && (maze[Rows][columns] == '8'))
				decide = true;
			break;
		default:
			cout << "Please Enter 1 or 2 or 3 or 4" << endl;

			break;
		}
	
		
		for (int i = 0; i < 50; i++)
		{
			for (int j = 0; j < 50; j++)
			{
				if (maze[i][j] == '.')
					count--;
			}
		}
		if (count == 0)
		{
			win = true;
			break;
		}
		
		for (int i = 0; i < 50; i++)
		{
			for (int j = 0; j < 50; j++)
			{
				cout << maze[i][j];
			}
			cout << endl;
		}
		if (decide)
			break;
		else
			continue;
	}

	if (win)
		cout << "Congratulations! You Won the Game" << endl;
	else if(decide)
	cout << "Oops ! You Lost the Game "<< endl;
}
