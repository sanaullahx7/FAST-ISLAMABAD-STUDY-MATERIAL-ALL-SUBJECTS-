 ///NAME= SANA ULLAH FAROOQI
 //CLASS =BSDS(A)
 //ROLL NO = 23I-2594




#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
    srand(static_cast<unsigned int>(time(0)));

    const int noofdays = 60;
    int bit[noofdays];

    
    for (int i = 0; i < noofdays; ++i) {
        bit[i] = rand() % 21 - 10;
    }

    cout << "Profit and Loss in 60 Days ";
    for (int i = 0; i < noofdays; ++i) {
        cout << bit[i] << " ";
    }
    cout << endl;

    int profitmaximum = 0;
    int start = 0, end = 0;

    for (int i = 0; i < noofdays; ++i) {
        int sum = 0;
        int cstart = i;

        for (int j = i; j < noofdays; ++j) {
            sum += bit[j];

            if (sum > profitmaximum) {
                profitmaximum = sum;
                start = cstart;
                end = j;
            }

            if (sum < 0) {
                sum -= bit[cstart++];
            }
        }
    }

    cout << "Max Profit: " << profitmaximum << endl;
    cout << "Start Index: " << start << endl;
    cout << "End Index: " << end << endl;

    return 0;
}
