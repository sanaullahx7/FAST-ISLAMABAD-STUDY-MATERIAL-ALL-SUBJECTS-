 ///NAME= SANA ULLAH FAROOQI
 //CLASS =BSDS(A)
 //ROLL NO = 23I-2594




#include<iostream>
constexpr double THRESHOLD = 0.000001;
using namespace std;
int main()
{
    double valueofpi = 0.0;
    for(int k=1; ; ++k)
    {
        double term = 1.0 / (2*k-1);
        if(k%2==1)
        {
            valueofpi += term;
        }
        else{
            valueofpi-=term;
        }
        if(term < THRESHOLD)
        {
            break;
        }

    }
    valueofpi *=4;
    cout<<" Approximated value of pi is: " <<valueofpi <<endl;
    return 0;
}
    
    








//             pi -= term;
//         }

//         if (term < THRESHOLD) {
//             break;
//         }
//     }

//     pi *= 4;

//     std::cout << "Pi is approximately " << pi << std::endl;

//     return 0;
// }
