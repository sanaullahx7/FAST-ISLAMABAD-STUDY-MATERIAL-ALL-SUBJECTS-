#include "network.h"

// The implementation is already in the header file since all methods are defined inline
// This file is kept for consistency and future expansion 