#ifndef NETWORK_H
#define NETWORK_H

#include <iostream>
#include <string>
#include "router.h"
#include "LinearList.h"
#include "message.h"
#include "queue.h"

class Network {
private:
    struct RouterNode {
        Router* router;
        RouterNode* next;
        RouterNode(Router* r) : router(r), next(nullptr) {}
    };

    RouterNode* head;
    int size;

    // Helper function to check if two routers are connected
    bool areRoutersConnected(Router* r1, Router* r2) {
        return r1->isConnected(r2->getIP()) && r2->isConnected(r1->getIP());
    }

    // Helper function to print routing information
    void printRoutingInfo(const std::string& srcIP, const std::string& destIP, 
                         const std::string& currentIP, const std::string& nextHop) {
        std::cout << "Routing: " << srcIP << " -> " << currentIP 
                  << " -> " << nextHop << " -> " << destIP << std::endl;
    }

    void clear() {
        while (head) {
            RouterNode* temp = head;
            head = head->next;
            delete temp->router;
            delete temp;
        }
        size = 0;
    }

public:
    Network() : head(nullptr), size(0) {}

    ~Network() {
        clear();
    }

    void addRouter(Router* router) {
        if (!router) {
            std::cout << "Error: Cannot add null router" << std::endl;
            return;
        }

        // Check if router with same IP already exists
        RouterNode* current = head;
        while (current) {
            if (current->router->getIP() == router->getIP()) {
                std::cout << "Error: Router with IP " << router->getIP() 
                         << " already exists" << std::endl;
                return;
            }
            current = current->next;
        }

        // Add new router
        RouterNode* newNode = new RouterNode(router);
        newNode->next = head;
        head = newNode;
        size++;
        std::cout << "Added router with IP: " << router->getIP() << std::endl;
    }

    void connectRouters(const std::string& ip1, const std::string& ip2) {
        Router* r1 = findRouterByIP(ip1);
        Router* r2 = findRouterByIP(ip2);

        if (!r1 || !r2) {
            std::cout << "Error: One or both routers not found" << std::endl;
            return;
        }

        if (areRoutersConnected(r1, r2)) {
            std::cout << "Routers already connected" << std::endl;
            return;
        }

        r1->addConnection(ip2);
        r2->addConnection(ip1);
        std::cout << "Connected routers: " << ip1 << " <-> " << ip2 << std::endl;
    }

    Router* findRouterByIP(const std::string& ip) {
        RouterNode* current = head;
        while (current) {
            if (current->router->getIP() == ip) {
                return current->router;
            }
            current = current->next;
        }
        return nullptr;
    }

    void sendMessage(const std::string& srcIP, const std::string& destIP, Message msg) {
        Router* sourceRouter = findRouterByIP(srcIP);
        Router* destRouter = findRouterByIP(destIP);

        if (!sourceRouter || !destRouter) {
            std::cout << "Error: Source or destination router not found" << std::endl;
            return;
        }

        // Initialize message with source and destination
        msg.setSourceIP(srcIP);
        msg.setDestinationIP(destIP);

        // Start routing from source router
        sourceRouter->receiveMessage(msg);
        sourceRouter->processMessages();

        // Continue routing until message reaches destination
        Router* currentRouter = sourceRouter;
        int hopCount = 0;
        const int MAX_HOPS = 10;  // Prevent infinite loops

        while (hopCount < MAX_HOPS) {
            // Find next router in path
            std::string nextHop = currentRouter->getNextHop(destIP);
            if (nextHop == "NOT FOUND") {
                std::cout << "Error: No route found to destination" << std::endl;
                return;
            }

            Router* nextRouter = findRouterByIP(nextHop);
            if (!nextRouter) {
                std::cout << "Error: Next hop router not found" << std::endl;
                return;
            }

            printRoutingInfo(srcIP, destIP, currentRouter->getIP(), nextHop);
            msg.addTrace(currentRouter->getIP());

            // Forward message to next router
            currentRouter->forwardMessagesTo(*nextRouter);
            nextRouter->processMessages();

            if (nextHop == destIP) {
                std::cout << "Message delivered to destination: " << destIP << std::endl;
                msg.printMessage();
                return;
            }

            currentRouter = nextRouter;
            hopCount++;
        }

        if (hopCount >= MAX_HOPS) {
            std::cout << "Error: Message exceeded maximum hop count" << std::endl;
        }
    }
};

#endif // NETWORK_H
