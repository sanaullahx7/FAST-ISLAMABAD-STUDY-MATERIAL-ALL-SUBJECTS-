#include <iostream>
#include <string>
#include "network.h"
#include "router.h"
#include "message.h"

void setupNetwork(Network& network) {
    // Create routers
    Router* r1 = new Router("192.168.1.1");
    Router* r2 = new Router("192.168.1.2");
    Router* r3 = new Router("192.168.1.3");
    Router* r4 = new Router("192.168.1.4");
    Router* r5 = new Router("192.168.1.5");

    // Add routers to network
    network.addRouter(r1);
    network.addRouter(r2);
    network.addRouter(r3);
    network.addRouter(r4);
    network.addRouter(r5);

    // Connect routers
    network.connectRouters("192.168.1.1", "192.168.1.2");
    network.connectRouters("192.168.1.2", "192.168.1.3");
    network.connectRouters("192.168.1.3", "192.168.1.4");
    network.connectRouters("192.168.1.4", "192.168.1.5");
    network.connectRouters("192.168.1.1", "192.168.1.3");  // Shortcut path

    // Set up routing tables
    r1->addRoute("192.168.1.2", "192.168.1.2");
    r1->addRoute("192.168.1.3", "192.168.1.3");
    r1->addRoute("192.168.1.4", "192.168.1.3");
    r1->addRoute("192.168.1.5", "192.168.1.3");

    r2->addRoute("192.168.1.1", "192.168.1.1");
    r2->addRoute("192.168.1.3", "192.168.1.3");
    r2->addRoute("192.168.1.4", "192.168.1.3");
    r2->addRoute("192.168.1.5", "192.168.1.3");

    r3->addRoute("192.168.1.1", "192.168.1.1");
    r3->addRoute("192.168.1.2", "192.168.1.2");
    r3->addRoute("192.168.1.4", "192.168.1.4");
    r3->addRoute("192.168.1.5", "192.168.1.4");

    r4->addRoute("192.168.1.1", "192.168.1.3");
    r4->addRoute("192.168.1.2", "192.168.1.3");
    r4->addRoute("192.168.1.3", "192.168.1.3");
    r4->addRoute("192.168.1.5", "192.168.1.5");

    r5->addRoute("192.168.1.1", "192.168.1.4");
    r5->addRoute("192.168.1.2", "192.168.1.4");
    r5->addRoute("192.168.1.3", "192.168.1.4");
    r5->addRoute("192.168.1.4", "192.168.1.4");
}

void testMessageRouting(Network& network) {
    std::cout << "\n=== Testing Message Routing ===\n";

    // Test case 1: Direct path
    std::cout << "\nTest Case 1: Direct path (R1 -> R2)\n";
    Message msg1(1, "192.168.1.1", "192.168.1.2", "Hello from R1 to R2", 1);
    network.sendMessage("192.168.1.1", "192.168.1.2", msg1);

    // Test case 2: Shortcut path
    std::cout << "\nTest Case 2: Shortcut path (R1 -> R3)\n";
    Message msg2(2, "192.168.1.1", "192.168.1.3", "Hello from R1 to R3", 2);
    network.sendMessage("192.168.1.1", "192.168.1.3", msg2);

    // Test case 3: Long path
    std::cout << "\nTest Case 3: Long path (R1 -> R5)\n";
    Message msg3(3, "192.168.1.1", "192.168.1.5", "Hello from R1 to R5", 3);
    network.sendMessage("192.168.1.1", "192.168.1.5", msg3);

    // Test case 4: Invalid destination
    std::cout << "\nTest Case 4: Invalid destination\n";
    Message msg4(4, "192.168.1.1", "192.168.1.6", "Hello to non-existent router", 4);
    network.sendMessage("192.168.1.1", "192.168.1.6", msg4);
}

void displayRouterInfo(Network& network) {
    std::cout << "\n=== Router Information ===\n";
    Router* r1 = network.findRouterByIP("192.168.1.1");
    Router* r2 = network.findRouterByIP("192.168.1.2");
    Router* r3 = network.findRouterByIP("192.168.1.3");
    Router* r4 = network.findRouterByIP("192.168.1.4");
    Router* r5 = network.findRouterByIP("192.168.1.5");

    if (r1) {
        std::cout << "\nRouter 1 Routing Table:\n";
        r1->showRoutingTable();
    }
    if (r2) {
        std::cout << "\nRouter 2 Routing Table:\n";
        r2->showRoutingTable();
    }
    if (r3) {
        std::cout << "\nRouter 3 Routing Table:\n";
        r3->showRoutingTable();
    }
    if (r4) {
        std::cout << "\nRouter 4 Routing Table:\n";
        r4->showRoutingTable();
    }
    if (r5) {
        std::cout << "\nRouter 5 Routing Table:\n";
        r5->showRoutingTable();
    }
}

int main() {
    std::cout << "Network Routing System Test\n";
    std::cout << "==========================\n";

    Network network;
    
    // Set up the network
    setupNetwork(network);
    
    // Display router information
    displayRouterInfo(network);
    
    // Test message routing
    testMessageRouting(network);

    return 0;
}
