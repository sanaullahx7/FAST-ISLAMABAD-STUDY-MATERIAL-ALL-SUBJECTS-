#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <string>

class Queue {
private:
    struct Node {
        std::string data;
        Node* next;
        Node(const std::string& val) : data(val), next(nullptr) {}
    };

    Node* front;
    Node* rear;
    int size;

public:
    Queue() : front(nullptr), rear(nullptr), size(0) {}

    ~Queue() {
        clear();
    }

    void enqueue(const std::string& value) {
        Node* newNode = new Node(value);
        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        ++size;
    }

    std::string dequeue() {
        if (isEmpty()) return "";
        Node* temp = front;
        std::string value = temp->data;
        front = front->next;
        if (front == nullptr)
            rear = nullptr;
        delete temp;
        --size;
        return value;
    }

    std::string peek() const {
        if (isEmpty()) return "";
        return front->data;
    }

    bool isEmpty() const {
        return front == nullptr;
    }

    int getSize() const {
        return size;
    }

    void clear() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    void printQueue() const {
        Node* temp = front;
        while (temp) {
            std::cout << temp->data << " <- ";
            temp = temp->next;
        }
        std::cout << "NULL\n";
    }
};

#endif // QUEUE_H
