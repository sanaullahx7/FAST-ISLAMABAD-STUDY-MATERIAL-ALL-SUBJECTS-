#ifndef LINEARLIST_H
#define LINEARLIST_H

#include <iostream>
#include <string>

class LinearList {
private:
    struct Node {
        std::string data;
        Node* next;
        Node(const std::string& val) : data(val), next(nullptr) {}
    };

    Node* head;
    int size;

public:
    LinearList() : head(nullptr), size(0) {}

    ~LinearList() {
        clear();
    }

    void insertAtEnd(const std::string& value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next)
                temp = temp->next;
            temp->next = newNode;
        }
        ++size;
    }

    bool insertAt(int index, const std::string& value) {
        if (index < 0 || index > size) return false;
        Node* newNode = new Node(value);
        if (index == 0) {
            newNode->next = head;
            head = newNode;
        } else {
            Node* temp = head;
            for (int i = 0; i < index - 1; ++i)
                temp = temp->next;
            newNode->next = temp->next;
            temp->next = newNode;
        }
        ++size;
        return true;
    }

    bool removeAt(int index) {
        if (index < 0 || index >= size) return false;
        Node* temp = head;
        if (index == 0) {
            head = head->next;
            delete temp;
        } else {
            for (int i = 0; i < index - 1; ++i)
                temp = temp->next;
            Node* toDelete = temp->next;
            temp->next = toDelete->next;
            delete toDelete;
        }
        --size;
        return true;
    }

    std::string get(int index) const {
        if (index < 0 || index >= size) return "";
        Node* temp = head;
        for (int i = 0; i < index; ++i)
            temp = temp->next;
        return temp->data;
    }

    int getSize() const {
        return size;
    }

    void printList() const {
        Node* temp = head;
        while (temp) {
            std::cout << temp->data << " -> ";
            temp = temp->next;
        }
        std::cout << "NULL\n";
    }

    void clear() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        size = 0;
    }
};

#endif // LINEARLIST_H
