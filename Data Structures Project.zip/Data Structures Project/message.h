#ifndef MESSAGE_H
#define MESSAGE_H

#include <string>
#include <iostream>

class Message {
private:
    static const int MAX_TRACE_ROUTE = 10;  // Maximum number of routers in trace route
    int id;
    std::string sourceIP;
    std::string destinationIP;
    std::string content;
    int priority;
    std::string traceRoute[MAX_TRACE_ROUTE];
    int traceCount;

public:
    // Constructors
    Message();
    Message(int id, const std::string& source, const std::string& dest, 
            const std::string& content, int priority);

    // Getters
    int getID() const;
    std::string getSourceIP() const;
    std::string getDestinationIP() const;
    std::string getContent() const;
    int getPriority() const;

    // Setters
    void setID(int id);
    void setSourceIP(const std::string& source);
    void setDestinationIP(const std::string& dest);
    void setContent(const std::string& content);
    void setPriority(int priority);

    // Trace route functionality
    void addTrace(const std::string& routerIP);
    void printTraceRoute() const;
    void printMessage() const;
};

#endif // MESSAGE_H
