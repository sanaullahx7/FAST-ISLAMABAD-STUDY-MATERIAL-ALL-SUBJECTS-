#ifndef SPLAYTREE_H
#define SPLAYTREE_H

#include <iostream>
#include <string>

class SplayTree {
private:
    struct Node {
        std::string key;
        std::string value;
        Node* left;
        Node* right;

        Node(const std::string& k, const std::string& v)
            : key(k), value(v), left(nullptr), right(nullptr) {}
    };

    Node* root;

    // Right rotate
    Node* rightRotate(Node* x) {
        Node* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    // Left rotate
    Node* leftRotate(Node* x) {
        Node* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    // Splaying
    Node* splay(Node* root, const std::string& key) {
        if (!root || root->key == key)
            return root;

        // Key in left subtree
        if (key < root->key) {
            if (!root->left) return root;

            if (key < root->left->key) {
                root->left->left = splay(root->left->left, key);
                root = rightRotate(root);
            } else if (key > root->left->key) {
                root->left->right = splay(root->left->right, key);
                if (root->left->right)
                    root->left = leftRotate(root->left);
            }

            return (root->left == nullptr) ? root : rightRotate(root);
        }
        // Key in right subtree
        else {
            if (!root->right) return root;

            if (key > root->right->key) {
                root->right->right = splay(root->right->right, key);
                root = leftRotate(root);
            } else if (key < root->right->key) {
                root->right->left = splay(root->right->left, key);
                if (root->right->left)
                    root->right = rightRotate(root->right);
            }

            return (root->right == nullptr) ? root : leftRotate(root);
        }
    }

    void deleteTree(Node* node) {
        if (!node) return;
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }

    void inOrder(Node* node) const {
        if (!node) return;
        inOrder(node->left);
        std::cout << node->key << ": " << node->value << std::endl;
        inOrder(node->right);
    }

public:
    SplayTree() : root(nullptr) {}

    ~SplayTree() {
        deleteTree(root);
    }

    void insert(const std::string& key, const std::string& value) {
        if (!root) {
            root = new Node(key, value);
            return;
        }

        root = splay(root, key);

        if (root->key == key) {
            root->value = value;
            return;
        }

        Node* newNode = new Node(key, value);

        if (key < root->key) {
            newNode->right = root;
            newNode->left = root->left;
            root->left = nullptr;
        } else {
            newNode->left = root;
            newNode->right = root->right;
            root->right = nullptr;
        }

        root = newNode;
    }

    std::string search(const std::string& key) {
        root = splay(root, key);
        if (root && root->key == key)
            return root->value;
        return "NOT FOUND";
    }

    void display() const {
        inOrder(root);
    }
};

#endif // SPLAYTREE_H
