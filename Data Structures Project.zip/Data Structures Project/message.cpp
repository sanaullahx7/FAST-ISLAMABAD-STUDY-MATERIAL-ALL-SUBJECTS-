#include "message.h"

Message::Message() : id(0), sourceIP(""), destinationIP(""), content(""), priority(0), traceCount(0) {}

Message::Message(int id, const std::string& source, const std::string& dest, 
                const std::string& content, int priority)
    : id(id), sourceIP(source), destinationIP(dest), content(content), 
      priority(priority), traceCount(0) {}

int Message::getID() const {
    return id;
}

std::string Message::getSourceIP() const {
    return sourceIP;
}

std::string Message::getDestinationIP() const {
    return destinationIP;
}

std::string Message::getContent() const {
    return content;
}

int Message::getPriority() const {
    return priority;
}

void Message::setID(int id) {
    this->id = id;
}

void Message::setSourceIP(const std::string& source) {
    sourceIP = source;
}

void Message::setDestinationIP(const std::string& dest) {
    destinationIP = dest;
}

void Message::setContent(const std::string& content) {
    this->content = content;
}

void Message::setPriority(int priority) {
    this->priority = priority;
}

void Message::addTrace(const std::string& routerIP) {
    if (traceCount < MAX_TRACE_ROUTE) {
        traceRoute[traceCount++] = routerIP;
    }
}

void Message::printTraceRoute() const {
    std::cout << "Message Trace Route:\n";
    for (int i = 0; i < traceCount; ++i) {
        std::cout << traceRoute[i];
        if (i < traceCount - 1) {
            std::cout << " -> ";
        }
    }
    std::cout << std::endl;
}

void Message::printMessage() const {
    std::cout << "\nMessage Details:\n";
    std::cout << "ID: " << id << std::endl;
    std::cout << "Source: " << sourceIP << std::endl;
    std::cout << "Destination: " << destinationIP << std::endl;
    std::cout << "Content: " << content << std::endl;
    std::cout << "Priority: " << priority << std::endl;
    printTraceRoute();
} 