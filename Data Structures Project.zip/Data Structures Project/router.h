#ifndef ROUTER_H
#define ROUTER_H

#include <iostream>
#include <string>
#include "message.h"
#include "LinearList.h"
#include "SplayTree.h"
#include "queue.h"

class Router {
private:
    std::string routerIP;
    LinearList connections;  // List of connected router IPs
    Queue incomingQueue;
    Queue outgoingQueue;
    SplayTree routingTable;
    Message currentMessage;  // Store the current message being processed

public:
    Router(const std::string& ip) : routerIP(ip) {}

    // Get router's IP address
    std::string getIP() const {
        return routerIP;
    }

    // Check if router is connected to a specific IP
    bool isConnected(const std::string& ip) const {
        for (int i = 0; i < connections.getSize(); ++i) {
            if (connections.get(i) == ip) {
                return true;
            }
        }
        return false;
    }

    // Add a connection to another router
    void addConnection(const std::string& ip) {
        if (!isConnected(ip)) {
            connections.insertAtEnd(ip);
        }
    }

    // Add a route to the routing table
    void addRoute(const std::string& destinationIP, const std::string& nextHop) {
        routingTable.insert(destinationIP, nextHop);
    }

    // Get next hop for a destination
    std::string getNextHop(const std::string& destinationIP) {
        return routingTable.search(destinationIP);
    }

    // Receive a message into the incoming queue
    void receiveMessage(const Message& msg) {
        currentMessage = msg;  // Store the message
        incomingQueue.enqueue(msg.getSourceIP() + "|" + msg.getDestinationIP());  // Store both source and destination
    }

    // Process all messages in incoming queue
    void processMessages() {
        while (!incomingQueue.isEmpty()) {
            std::string queueData = incomingQueue.dequeue();
            size_t separator = queueData.find('|');
            if (separator == std::string::npos) continue;  // Skip invalid data

            std::string sourceIP = queueData.substr(0, separator);
            std::string destination = queueData.substr(separator + 1);
            std::string nextHop = routingTable.search(destination);

            if (nextHop != "NOT FOUND") {
                std::cout << "Routing from " << routerIP << " to " << destination
                          << " via " << nextHop << std::endl;
                outgoingQueue.enqueue(nextHop + "|" + destination);  // Store next hop and destination
            } else {
                std::cout << "No route for message to " << destination << " from " << routerIP << std::endl;
            }
        }
    }

    // Get and clear the outgoing queue
    void forwardMessagesTo(Router& nextRouter) {
        while (!outgoingQueue.isEmpty()) {
            std::string queueData = outgoingQueue.dequeue();
            size_t separator = queueData.find('|');
            if (separator == std::string::npos) continue;  // Skip invalid data

            std::string nextHop = queueData.substr(0, separator);
            std::string destination = queueData.substr(separator + 1);

            Message msg = currentMessage;  // Create a copy of the current message
            msg.setSourceIP(routerIP);
            msg.setDestinationIP(destination);
            nextRouter.receiveMessage(msg);
        }
    }

    // Display routing table
    void showRoutingTable() const {
        std::cout << "Routing Table of " << routerIP << ":\n";
        routingTable.display();
    }
};

#endif // ROUTER_H
