
// Name: Sana Ullah
// Roll No: 23I-2594
// Section: DS-A

#include <iostream>
using namespace std;

struct Node {
    int value;
    int height;
    Node* left;
    Node* right;
    Node(int val) : value(val), height(1), left(NULL), right(NULL) {}
};

int max(int a, int b) {
    return (a > b) ? a : b;
}

int height(Node* n) {
    return n ? n->height : 0;
}

int getBalance(Node* n) {
    return n ? height(n->left) - height(n->right) : 0;
}

void updateHeight(Node* n) {
    if (n) n->height = 1 + max(height(n->left), height(n->right));
}

Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;
    x->right = y;
    y->left = T2;
    updateHeight(y);
    updateHeight(x);
    return x;
}

Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;
    y->left = x;
    x->right = T2;
    updateHeight(x);
    updateHeight(y);
    return y;
}

Node* insertBST(Node* root, int val) {
    if (!root) return new Node(val);
    if (val < root->value)
        root->left = insertBST(root->left, val);
    else
        root->right = insertBST(root->right, val);
    return root;
}

Node* insertAVL(Node* root, int val) {
    if (!root) return new Node(val);
    if (val < root->value)
        root->left = insertAVL(root->left, val);
    else if (val > root->value)
        root->right = insertAVL(root->right, val);
    else
        return root;

    updateHeight(root);
    int balance = getBalance(root);

    if (balance > 1 && val < root->left->value)
        return rightRotate(root);
    if (balance < -1 && val > root->right->value)
        return leftRotate(root);
    if (balance > 1 && val > root->left->value) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (balance < -1 && val < root->right->value) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

int calculateMana(Node* node, int rootDepth, int currentDepth) {
    if (!node) return 0;
    int mana = (rootDepth - currentDepth + 1) * node->value;
    return mana + calculateMana(node->left, rootDepth, currentDepth + 1)
                + calculateMana(node->right, rootDepth, currentDepth + 1);
}

int calculateEssence(Node* node) {
    if (!node) return 0;
    if (!node->left && !node->right)
        return node->value * 2;
    return calculateEssence(node->left) + calculateEssence(node->right);
}

void inorder(Node* root) {
    if (!root) return;
    inorder(root->left);
    cout << root->value << " ";
    inorder(root->right);
}

int getDepth(Node* node) {
    if (!node) return 0;
    return 1 + max(getDepth(node->left), getDepth(node->right));
}

int getMinDepth(Node* node) {
    if (!node) return 0;
    if (!node->left && !node->right) return 1;
    if (!node->left) return 1 + getMinDepth(node->right);
    if (!node->right) return 1 + getMinDepth(node->left);
    return 1 + min(getMinDepth(node->left), getMinDepth(node->right));
}

bool isPerfectlyBalanced(Node* root, int n, int depth = -1, int current = 0) {
    if (!root) return true;
    if (!root->left && !root->right) {
        if (depth == -1) return true;
        return current == depth;
    }
    if (!root->left || !root->right) return false;
    return isPerfectlyBalanced(root->left, n, depth, current + 1) &&
           isPerfectlyBalanced(root->right, n, depth, current + 1);
}

int main() {
    Node* player1 = NULL;
    Node* player2 = NULL;
    int mana1 = 0, mana2 = 0;
    int choice, val;
    bool turn = true;
    int nodes1 = 0, nodes2 = 0;
    while (true) {
        cout << "\nPlayer " << (turn ? 1 : 2) << "'s turn\n";
        cout << "1. Plant (Insert Node)\n2. Show Inorder\n3. Show Mana & Essence\n4. Exit\nEnter choice: ";
        cin >> choice;
        if (choice == 1) {
            cout << "Enter value (1-100): ";
            cin >> val;
            if (turn) {
                player1 = insertAVL(player1, val);
                nodes1++;
                mana1 = calculateMana(player1, getDepth(player1), 1);
            } else {
                player2 = insertAVL(player2, val);
                nodes2++;
                mana2 = calculateMana(player2, getDepth(player2), 1);
            }
        } else if (choice == 2) {
            cout << "Tree: ";
            if (turn)
                inorder(player1);
            else
                inorder(player2);
            cout << "\n";
        } else if (choice == 3) {
            int m = turn ? mana1 : mana2;
            int e = turn ? calculateEssence(player1) : calculateEssence(player2);
            cout << "Mana: " << m << ", Essence: " << e << "\n";
        } else break;

        if ((turn && mana1 >= 1000) || (!turn && mana2 >= 1000)) {
            cout << "Player " << (turn ? 1 : 2) << " wins by 1000 Mana!\n";
            break;
        }

        if ((turn && isPerfectlyBalanced(player1, nodes1)) || (!turn && isPerfectlyBalanced(player2, nodes2))) {
            cout << "Player " << (turn ? 1 : 2) << " wins with a perfectly balanced tree!\n";
            break;
        }

        int h1 = getDepth(player1), h2 = getDepth(player2);
        int l1 = getMinDepth(player1), l2 = getMinDepth(player2);
        if (h1 - l1 > 5) {
            cout << "Player 2 wins! Player 1's tree unbalanced.\n";
            break;
        }
        if (h2 - l2 > 5) {
            cout << "Player 1 wins! Player 2's tree unbalanced.\n";
            break;
        }

        turn = !turn;
    }
    return 0;
}
