
// Name: Sana Ullah
// Roll No: 23I-2594
// Section: DS-A

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Node {
    char ch;
    int freq;
    Node* left;
    Node* right;
};

struct CodeMap {
    char ch;
    string code;
};

void sort(Node* arr[], int n) {
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (arr[j]->freq > arr[j + 1]->freq) {
                Node* temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
}

Node* buildTree(Node* arr[], int size) {
    while (size > 1) {
        sort(arr, size);
        Node* left = arr[0];
        Node* right = arr[1];
        Node* merged = new Node;
        merged->ch = '*';
        merged->freq = left->freq + right->freq;
        merged->left = left;
        merged->right = right;
        for (int i = 2; i < size; i++)
            arr[i - 2] = arr[i];
        arr[size - 2] = merged;
        size--;
    }
    return arr[0];
}

void generateCodes(Node* root, string code, CodeMap map[], int &idx) {
    if (!root) return;
    if (!root->left && !root->right) {
        map[idx].ch = root->ch;
        map[idx].code = code;
        idx++;
        return;
    }
    generateCodes(root->left, code + "0", map, idx);
    generateCodes(root->right, code + "1", map, idx);
}

int main() {
    string text;
    cout << "Enter text: ";
    getline(cin, text);

    int freq[128] = {0};
    for (char ch : text)
        freq[int(ch)]++;

    Node* arr[128];
    int size = 0;
    for (int i = 0; i < 128; i++) {
        if (freq[i] > 0) {
            Node* node = new Node;
            node->ch = char(i);
            node->freq = freq[i];
            node->left = node->right = NULL;
            arr[size++] = node;
        }
    }

    Node* root = buildTree(arr, size);
    CodeMap map[128];
    int idx = 0;
    generateCodes(root, "", map, idx);

    ofstream codemap("code.txt");
    for (int i = 0; i < idx; i++)
        codemap << map[i].ch << ":" << map[i].code << endl;
    codemap.close();

    string encoded = "";
    for (char ch : text)
        for (int i = 0; i < idx; i++)
            if (map[i].ch == ch)
                encoded += map[i].code;

    ofstream message("message.txt");
    message << encoded;
    message.close();

    cout << "Encoding complete.
";
    return 0;
}
