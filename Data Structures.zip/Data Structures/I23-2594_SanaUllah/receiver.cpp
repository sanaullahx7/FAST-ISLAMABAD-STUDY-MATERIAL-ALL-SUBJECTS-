
// Name: Sana Ullah
// Roll No: 23I-2594
// Section: DS-A

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct TreeNode {
    char ch;
    TreeNode* left;
    TreeNode* right;
    TreeNode() {
        ch = '*';
        left = right = NULL;
    }
};

void insert(TreeNode* root, string code, char ch) {
    TreeNode* curr = root;
    for (char c : code) {
        if (c == '0') {
            if (!curr->left) curr->left = new TreeNode;
            curr = curr->left;
        } else {
            if (!curr->right) curr->right = new TreeNode;
            curr = curr->right;
        }
    }
    curr->ch = ch;
}

int main() {
    ifstream codemap("code.txt");
    TreeNode* root = new TreeNode;
    string line;
    while (getline(codemap, line)) {
        if (line.length() < 3) continue;
        char ch = line[0];
        string code = line.substr(2);
        insert(root, code, ch);
    }
    codemap.close();

    ifstream message("message.txt");
    string encoded;
    getline(message, encoded);
    message.close();

    TreeNode* curr = root;
    string decoded = "";
    for (char bit : encoded) {
        if (bit == '0') curr = curr->left;
        else curr = curr->right;
        if (curr->left == NULL && curr->right == NULL) {
            decoded += curr->ch;
            curr = root;
        }
    }

    cout << "Decoded message: " << decoded << endl;
    return 0;
}
